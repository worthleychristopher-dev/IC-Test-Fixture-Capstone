import serial
import time

PORT = "COM9"
BAUD = 115200

def read_line(ser: serial.Serial) -> str:
    return ser.readline().decode(errors="replace").strip()

def main():
    with serial.Serial(PORT, BAUD, timeout=1) as ser:
        # Some boards reset / reboot on port open; give it a moment
        time.sleep(0.3)
        ser.reset_input_buffer()

        print("Connected on", PORT)
        print("1/2/3 = toggle LED1/2/3")
        print("4 = status")
        print("q = quit")

        while True:
            s = input("> ").strip().lower()
            if s == "q":
                break
            elif s in ("1", "2", "3"):
                ser.write(f"TOG {s}\n".encode())
                print(read_line(ser) or "(no response)")
            elif s == "4":
                ser.write(b"STAT\n")
                print(read_line(ser) or "(no response)")
            else:
                print("Use 1/2/3/4 or q")

if __name__ == "__main__":
    main()
