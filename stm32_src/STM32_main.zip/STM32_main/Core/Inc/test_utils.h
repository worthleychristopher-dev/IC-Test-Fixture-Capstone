#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include "main.h"

void Test(ParsedState *state);
void Check_Connectivity(ParsedState *state);

#endif
